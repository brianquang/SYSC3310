#ifndef MY_FUNCTIONS_H
#define MY_FUNCTIONS_H

void increment(void);
#endif
