#include "my_functions.h"

extern int aWord;       // global variable 

int main(void)
{
	aWord = 1 + 0 + 3;    // sum of last 3 digit from student number
	increment();          // add 1 to the sum
	
	return 0;
}
