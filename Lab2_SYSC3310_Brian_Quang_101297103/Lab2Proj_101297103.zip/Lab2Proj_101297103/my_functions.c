#include "my_functions.h"

int aWord;                  // Initialize aWord variable

void increment(void)
{
	aWord = aWord + 1;        // Increment aWord by 1
}
