.\objects\my_functions.o: my_functions.c
.\objects\my_functions.o: my_functions.h
